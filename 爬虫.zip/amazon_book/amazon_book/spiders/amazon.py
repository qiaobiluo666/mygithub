# -*- coding: utf-8 -*-
import scrapy
from scrapy_redis.spiders import RedisSpider
from ..items import AmazonBookItem
class AmazonSpider(RedisSpider):
# class AmazonSpider(scrapy.Spider):
    name = 'amazon'
    allowed_domains = ['www.amazon.cn']
    # start_urls=['https://www.amazon.cn/%E5%9B%BE%E4%B9%A6/b/ref=sd_allcat_books_I1?ie=UTF8&node=658390051']
    base_url ='https://www.amazon.cn/%E5%9B%BE%E4%B9%A6/b/ref=sd_allcat_books_I1?ie=UTF8&node=658390051'
    redis_key = "redis_key:urls"

    def parse(self, response):
        node_list = response.xpath("//ul[@class='a-unordered-list a-nostyle a-vertical s-ref-indent-one']//li")
        # print(node_list,'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh')
        for node in node_list[:3]:
            type_link=node.xpath('./span/a/@href').extract_first()
            yield scrapy.Request(url=type_link, callback=self.type_book)

    def type_book(self, response):
        node_list = response.xpath("//ul[@class='a-unordered-list a-nostyle a-vertical s-ref-indent-two']//li")
        for node in node_list[:3]:
            book_link = node.xpath('./span/a/@href').extract_first()
            # print(book_link,'ddddddddddddddddddddddd')
            yield scrapy.Request(url=book_link, callback=self.book_info)

    def book_info(self, response):
        node_list = response.xpath("//div[@class='a-row s-result-list-parent-container']/ul/li")
        item=AmazonBookItem()
        for node in node_list[:3]:
            item['title']=node.xpath(".//a/h2/text()").extract_first()
            item['time'] = node.xpath(".//div[1]/span[3]/text()").extract_first()
            if node.xpath(".//div[2]/span[3]/text()").extract_first() is not None:
                item['author']=node.xpath(".//div[2]/span[2]/text()").extract_first()+node.xpath(".//div[2]/span[3]/text()").extract_first()
            else:
                item['author'] = node.xpath(".//div[2]/span[2]/text()").extract_first()
            item['type']=node.xpath(".//div[1]/a/h3/text()").extract_first()
            item['money']=node.xpath(".//div[2]/a/span[2]/text()").extract_first()
            item['index']=node.xpath(".//div[2]/i/text()").extract_first()
            yield item
