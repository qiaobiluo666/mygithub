# -*- coding: utf-8 -*-

# Define here the models for your spider middleware
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/spider-middleware.html

from scrapy import signals
import time
from scrapy.http import HtmlResponse
from selenium import webdriver

class SeleniumWebDriverMiddleWares(object):
    def __init__(self):
        pass
    def process_request(self, request, spider):
        # print(request.url,'llllllllllllllllllllllllllllllllllllllllll')
        if request.url != 'https://www.amazon.cn/%E5%9B%BE%E4%B9%A6/b/ref=sd_allcat_books_I1?ie=UTF8&node=658390051':
            driver_path = r'C:\Users\lenovo\AppData\Local\Google\Chrome\Application\chromedriver.exe'
            browse = webdriver.Chrome(executable_path=driver_path)
            browse.get(request.url)
            time.sleep(3)
            html = browse.page_source
            browse.quit()
            response = HtmlResponse(body=html.encode("utf-8"), request=request, url=browse.current_url,encoding="utf-8")
            return response
