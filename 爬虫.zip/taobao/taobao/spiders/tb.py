# -*- coding: utf-8 -*-
import scrapy


class TbSpider(scrapy.Spider):
    name = 'tb'
    allowed_domains = ['www.taobao.com']
    start_urls = ['https://login.taobao.com/member/login.jhtml']

    def parse(self, response):
        pass
