# -*- coding: utf-8 -*-

# Define here the models for your spider middleware
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/spider-middleware.html

from scrapy import signals
import time
from selenium import webdriver
from selenium.webdriver import ActionChains

class TaobaoMiddleware(object):
    driver_path=r'C:\Users\lenovo\AppData\Local\Google\Chrome\Application\chromedriver.exe'
    driver = webdriver.Chrome(executable_path=driver_path)
    driver.get("https://weibo.com/login.php?spm=a2107.1.0.0.3e3e11d9efGx5D&entry=taobao&goto=https%3A%2F%2Flogin.taobao.com%2Faso%2Ftvs%3Fdomain%3Dweibo%26sid%3Dc8887303a302b448cb91566f8ee1132d%26target%3D&goto2=")
    time.sleep(2)
    driver.find_element_by_xpath("//div[@class='inp username']/input").clear()
    driver.find_element_by_xpath("//div[@class='inp password']/input").clear()
    username = " "
    password = " "
    driver.find_element_by_xpath("//div[@class='inp username']/input").send_keys(username)
    time.sleep(1)
    driver.find_element_by_xpath("//div[@class='inp password']/input").send_keys(password)
    time.sleep(2)
    driver.find_element_by_xpath("//div[@class='btn_tip']/a[1]/span").click()
    # driver.get("https://login.taobao.com/member/login.jhtml")
    # driver.find_element_by_xpath("//*[@class='forget-pwd J_Quick2Static']").click()
    # time.sleep(3)
    # driver.find_element_by_id("TPL_username_1").clear()
    # driver.find_element_by_id("TPL_password_1").clear()
    # username=" "
    # password=" "
    # driver.find_element_by_id("TPL_username_1").send_keys(username)
    # time.sleep(2)
    # driver.find_element_by_id("TPL_password_1").send_keys(password)
    # action = ActionChains(driver)
    # if driver.find_element_by_xpath("//*[@id='nc_1_n1t']/span") is not None:
    #     source = driver.find_element_by_xpath("//*[@id='nc_1_n1t']/span")
    #     action.move_to_element(source).click_and_hold(source).perform()
    #     action.move_by_offset(258,0)
    #     action.release().perform()
    #     driver.find_element_by_xpath("//*[@id='J_SubmitStatic']").click()
    # else:
    #     time.sleep(2)
    #     driver.find_element_by_xpath("//*[@id='J_SubmitStatic']").click()
    cookie = " ".join([item["name"] + "=" + item["value"] + "\n" for item in driver.get_cookies()])
    print(cookie,'hhhhhhhhhhhhhhhhhhh')