import datetime,time

import pymysql
import redis
from django.http import HttpResponse, request
from django.shortcuts import render, redirect
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage  # 导入Paginator模块

r = redis.Redis(host='127.0.0.1', port=6379, decode_responses='utf-8')
# Create your views here.
def zhuang(func):
    def methon(request):
        if request.COOKIES.get("name"):
           return func(request)
        else:
            return  render(request,"login.html")
    return methon

def login(request):
    """"登录"""
    if request.method == "GET":
        return render(request, "login.html")
    else:
        userID = request.POST.get("p1")
        password1 = request.POST.get("p2")
        conn = pymysql.connect(host="127.0.0.1", port=3306,
                               user="root", password="root",
                               db="bookstore", charset="utf8")
        cursor = conn.cursor()
        cursor.execute("select user_name,user_password from user")
        username = cursor.fetchall()
        cursor = conn.cursor()
        conn.commit()
        cursor.close()
        conn.close()
        print(username)
        for i in username:
            if userID == i[0]:
                if password1 == i[1]:
                    response = redirect("index_person")
                    response.set_cookie("name", userID, max_age=10000)
                    return response
                else:
                    return HttpResponse("账号密码有误请重新输入111")
        else:
            return HttpResponse("账号密码有误请重新输入")

def register(request):
    """"注册"""
    if request.method == "GET":
        return render(request, "register.html")
    else:
        username = request.POST.get("p1")
        password = request.POST.get("p2")
        password1 = request.POST.get("p3")
        conn = pymysql.connect(host="127.0.0.1", port=3306,
                               user="root", password="root",
                               db="bookstore", charset="utf8")
        li = []
        cursor = conn.cursor()
        cursor.execute("select user_name from user")
        user = cursor.fetchall()
        for i in user:
            li.append(i[0])
        if password.isdigit is False:
            return HttpResponse("密码必须是数字")
        elif username in li:
            return HttpResponse("账号已经存在")
        elif password != password1:
            return HttpResponse("二次输入的密码不一致")
        else:
            cursor.execute("insert into user(user_name,user_password) values('%s','%s' )" % (username, password))
            conn.commit()
            cursor.close()
            conn.close()
            response = redirect("index_person")
            response.set_cookie("name", username, max_age=10000)
            return response

def index(request):
    """"首页"""
    conn = pymysql.connect(host="127.0.0.1", port=3306,
                           user="root", password="root",
                           db="bookstore", charset="utf8")
    cursor = conn.cursor()
    cursor.execute("select goods_name,goods_price,goods_sales,goods_img,goods_size,goods_id from goods")
    shop =  cursor.fetchall()
    conn.commit()
    cursor.close()

    cursor = conn.cursor()
    cursor.execute("select goods_sales,goods_id from goods")
    goods_sales = cursor.fetchall()

    li = []
    for i in goods_sales:
        li.append(i[0])

    li.sort(reverse=True)
    print(li, "ssssssssssssssssssssssssssssssssssssss")

    li123 = []
    for i in li[0:4]:
        print(i, "sdasdasdsadasdasdasdasdadad")
        cursor = conn.cursor()
        cursor.execute(
            "select goods_name,goods_price,goods_sales,goods_img,goods_size,goods_id from goods where goods_sales = '%s'" % (
                i))
        shop_main = cursor.fetchall()
        li123.append(shop_main[0])
    conn.commit()
    cursor.close()

    conn.close()

    paginator = Paginator(shop, 8)

    # 从前端获取当前的页码数,默认为1
    page = request.GET.get('page', 1)
    # 把当前的页码数转换成整数类型
    currentPage = int(page)
    try:
        print(page)
        shop = paginator.page(page)  # 获取当前页码的记录
    except PageNotAnInteger:
        shop = paginator.page(1)  # 如果用户输入的页码不是整数时,显示第1页的内容
    except EmptyPage:
        shop = paginator.page(paginator.num_pages)  # 如果用户输入的页数不在系统的页码列表中时,显示最后一页的内容
    return render(request,'index.html',context= {"a":shop,"b":li123[0:4]})


@zhuang
def shoppingcar(request):
    """"购物车"""

    user_name = request.COOKIES.get("name")
    conn = pymysql.connect(host="127.0.0.1", port=3306,
                           user="root", password="root",
                           db="bookstore", charset="utf8")
    cursor = conn.cursor()
    cursor.execute("select user_id from user where user_name='%s'" % user_name)
    user_id = cursor.fetchall()

    conn.commit()
    cursor.close()
    cursor = conn.cursor()
    cursor.execute("select goods_id,buy_number from shoppingcar  where user_id ='%s'" % user_id[0][0])
    goods_id = cursor.fetchall()

    conn.commit()
    cursor.close()
    li = []
    for i in goods_id:
        cursor = conn.cursor()
        cursor.execute("select goods_img,goods_name,goods_price,goods_id from goods where goods_id = '%s'" % i[0])
        goods_mess = cursor.fetchall()
        goods_mess = i + goods_mess[0]
        li.append(goods_mess)
        conn.commit()
        cursor.close()
    print(li)
    finalmoney = float()
    for i in li:
        money = i[1] * i[4]
        finalmoney += money
    print(finalmoney)
    cursor = conn.cursor()
    cursor.execute("select user_money from user where user_name = '%s'" % user_name)
    user_money = cursor.fetchall()
    user_money = user_money[0][0]
    money = user_money - finalmoney
    response = render(request, 'shoppingcar.html', context={'a': li, 'b': finalmoney})
    response.set_cookie("money", money,max_age=10000)
    conn.close()
    return response


@zhuang
def person(request):
    """"个人中心"""
    user_name = request.COOKIES.get("name")
    conn = pymysql.connect(host="127.0.0.1", port=3306,
                           user="root", password="root",
                           db="bookstore", charset="utf8")
    cursor = conn.cursor()
    cursor.execute("select user_name,user_money,user_power from user where user_name = '%s'"%user_name)
    user = cursor.fetchall()
    conn.commit()
    cursor.close()
    conn.close()
    return render(request,'person.html',context={'a':user[0]})
@zhuang
def superadmin(request):
    """"超级管理员"""
    if request.method == "GET":
        return render(request,'superadmin.html')
@zhuang
def admin(request):
    """"管理员"""
    if request.method == "GET":
        return render(request,'admin.html')
def goods_info(request):
    """"商品详情"""

    goods_info = request.GET.get("goods_id")
    conn = pymysql.connect(host="127.0.0.1", port=3306,
                           user="root", password="root",
                           db="bookstore", charset="utf8")
    cursor = conn.cursor()
    cursor.execute("select * from goods where goods_id = '%s' "%(goods_info))
    shop = cursor.fetchall()
    conn.commit()
    cursor.close()

    cursor = conn.cursor()
    cursor.execute("select user_id,goods_grade,goods_evaluate,shopped_time from shopped where goods_id = '%s'"%(goods_info))
    shopped = cursor.fetchall()
    conn.commit()
    cursor.close()






    li = []
    for i in shopped:
        cursor = conn.cursor()
        cursor.execute("select user_name from user where user_id = '%s'"%i[0])
        user_name = cursor.fetchall()
        conn.commit()
        cursor.close()
        user_name = user_name[0] + i
        li.append(user_name)




    conn.close()

    goods_id = request.GET.get('goods_id')
    user_name = request.COOKIES.get('name')
    if user_name:
        # 用户已登录，记录浏览记录
        key = 'history_%s' % user_name
        # key值为 用户名
        r.lrem(key, 0, goods_id)
        r.lpush(key, goods_id)
        r.ltrim(key, 0, 4)






    return render(request,'goods_info.html',context={'a':shop[0],'b':li})
def search(request):
    """"搜索"""
    name = request.POST.get('p1')
    conn = pymysql.connect(host="127.0.0.1", port=3306,
                           user="root", password="root",
                           db="bookstore", charset="utf8")
    cursor = conn.cursor()
    cursor.execute(
        "select goods_name,goods_price,goods_sales,goods_img,goods_size from goods where goods_name like '%%%%%s%%%%'" % name)
    shop = cursor.fetchall()
    conn.commit()
    cursor.close()
    conn.close()

    if shop ==():
        return HttpResponse("没有此输入结果")
    else:
        return render(request,'search.html',context={'a':shop,'b':name})
@zhuang
def add_checkout(request):
    """"下单成功"""
    if request.method == "GET":
        return render(request,"checkout.html")
    else:
        money = request.COOKIES.get("money")

        if float(money) <0:
            return HttpResponse("余额不足，请充值")
        else:
            time = datetime.datetime.now()
            user_name = request.COOKIES.get("name")
            conn = pymysql.connect(host="127.0.0.1", port=3306,
                                   user="root", password="root",
                                   db="bookstore", charset="utf8")
            cursor = conn.cursor()
            cursor.execute("select user_id from user where user_name='%s'" % user_name)
            user_id = cursor.fetchall()
            conn.commit()
            cursor.close()

            conn.commit()
            cursor.close()
            cursor = conn.cursor()
            cursor.execute("select goods_id,buy_number from shoppingcar  where user_id ='%s'" % user_id[0][0])
            goods_id = cursor.fetchall()

            conn.commit()
            cursor.close()

            for i in goods_id:
                cursor = conn.cursor()
                cursor.execute("select goods_price,goods_sales from goods where goods_id ='%s'" % i[0])
                goods_mess1 = cursor.fetchall()
                conn.commit()
                cursor.close()
                goods_sales = i[1]+goods_mess1[0][1]
                cursor = conn.cursor()
                cursor.execute("update bookstore.goods set goods_sales='%s'where goods_id ='%s'"%(goods_sales,i[0]))
                conn.commit()
                cursor.close()

                cursor = conn.cursor()
                cursor.execute("insert into shopped(user_id,goods_id,goods_price,buy_number,shopped_time)values('%s','%s','%s','%s','%s')"%(user_id[0][0],i[0],goods_mess1[0][0],i[1],time))
                conn.commit()
                cursor.close()



            cursor = conn.cursor()
            cursor.execute("delete from bookstore.shoppingcar;")
            conn.commit()
            cursor.close()
            conn.close()
            return redirect('checkout')

@zhuang
def evaluation(request):
    """"评价"""
    if request.method == "GET":
        goods_id = request.GET.get("goods_id")
        response = render(request,"evaluation.html")
        response.set_cookie("goods_id",goods_id,max_age=1000)
        print(goods_id,"ssssssssssssssssssssssssssssss")
        return response
    else:
        user_name = request.COOKIES.get("name")
        goods_grade = request.POST.get("p1")
        goods_evaluation =request.POST.get('p2')
        goods_id = request.COOKIES.get("goods_id")
        print(goods_grade,"111111111111111111111111111111111111111111111")
        print(goods_id,'ssssssssssssssssssssssssssssssssssssssssssssssssssss')
        conn = pymysql.connect(host="127.0.0.1", port=3306,
                               user="root", password="root",
                               db="bookstore", charset="utf8")

        cursor = conn.cursor()
        cursor.execute("select user_id from user where user_name='%s'" % user_name)
        user_id = cursor.fetchall()

        conn.commit()
        cursor.close()


        cursor =conn.cursor()
        cursor.execute("update bookstore.shopped set goods_grade ='%s',goods_evaluate = '%s' where goods_id = '%s' and user_id = '%s'"%(goods_grade,goods_evaluation,goods_id,user_id[0][0]))
        conn.commit()
        cursor.close()

        conn.close()
        return redirect('checkout')



def sort(request):
    """"分类"""
    print("---------------------------------------------------")
    goods_size = request.GET.get("goods_size")
    conn = pymysql.connect(host="127.0.0.1", port=3306,
                           user="root", password="root",
                           db="bookstore", charset="utf8")
    cursor = conn.cursor()
    cursor.execute("select goods_name,goods_price,goods_sales,goods_img,goods_size from goods where goods_size='%s'"%goods_size)
    shop = cursor.fetchall()
    conn.commit()
    cursor.close()
    conn.close()
    name1 =''
    if goods_size =='2':
        name1 = "历史"
    elif goods_size =='0':
        name1 ="科幻"
    elif goods_size =='1':
        name1 = "国外"
    elif goods_size =='3':
        name1 = "玄幻"
    print(name1)
    paginator = Paginator(shop, 8)

    # 从前端获取当前的页码数,默认为1
    page = request.GET.get('page', 1)
    # 把当前的页码数转换成整数类型
    currentPage = int(page)
    try:
        print(page)
        shop = paginator.page(page)  # 获取当前页码的记录
    except PageNotAnInteger:
        shop = paginator.page(1)  # 如果用户输入的页码不是整数时,显示第1页的内容
    except EmptyPage:
        shop = paginator.page(paginator.num_pages)  # 如果用户输入的页数不在系统的页码列表中时,显示最后一页的内容
    return render(request,'sort.html',context={'a':shop,'b':goods_size,'c':name1})
@zhuang
def index_person(request):
    """登录后的主界面"""
    conn = pymysql.connect(host="127.0.0.1", port=3306,
                           user="root", password="root",
                           db="bookstore", charset="utf8")
    cursor = conn.cursor()
    cursor.execute("select goods_name,goods_price,goods_sales,goods_img,goods_size,goods_id from goods")
    shop = cursor.fetchall()
    conn.commit()
    cursor.close()


    cursor = conn.cursor()
    cursor.execute("select goods_sales,goods_id from goods")
    goods_sales = cursor.fetchall()

    li = []
    for i in goods_sales:
        li.append(i[0])

    li.sort(reverse=True)
    print(li,"ssssssssssssssssssssssssssssssssssssss")

    li123 = []
    for i in li[0:4]:
        print(i,"sdasdasdsadasdasdasdasdadad")
        cursor = conn.cursor()
        cursor.execute("select goods_name,goods_price,goods_sales,goods_img,goods_size,goods_id from goods where goods_sales = '%s'"%(i))
        shop_main = cursor.fetchall()
        li123.append(shop_main[0])
    conn.commit()
    cursor.close()


    conn.close()

    paginator = Paginator(shop, 8)
    # 从前端获取当前的页码数,默认为1
    page = request.GET.get('page', 1)
    # 把当前的页码数转换成整数类型
    currentPage = int(page)
    try:
        print(page)
        shop = paginator.page(page)  # 获取当前页码的记录
    except PageNotAnInteger:
        shop = paginator.page(1)  # 如果用户输入的页码不是整数时,显示第1页的内容
    except EmptyPage:
        shop = paginator.page(paginator.num_pages)  # 如果用户输入的页数不在系统的页码列表中时,显示最后一页的内容
    return render(request, 'index_person.html', context={"a": shop,'b':li123[0:4]})
@zhuang
def money(request):
    """"充值"""
    if request.method == "GET":
        return render(request,'money.html')
    else:
        money = request.POST.get("p1")
        print(money,"-------------------------------------------------------------")
        if int(money)<0:
            return HttpResponse("您还想空手被扣钱？")
        else:
            user_name = request.COOKIES.get("name")
            conn = pymysql.connect(host="127.0.0.1", port=3306,
                                   user="root", password="root",
                                   db="bookstore", charset="utf8")
            cursor = conn.cursor()
            cursor.execute("select user_money from user where user_name = '%s'" % user_name)
            user_money = cursor.fetchall()
            user_money = user_money[0][0]
            print(user_money,"====================================================")
            money = float(money) + user_money
            cursor = conn.cursor()
            cursor.execute("update bookstore.user  set  user_money ='%s' where user_name = '%s';"%(money,user_name))
            conn.commit()
            cursor.close()
            conn.close()
            response = redirect("person")
            return response
@zhuang
def change_pass(request):
    """"修改密码"""
    if request.method =="GET":
        return render(request,"change_pass.html")
    else:
        user_name = request.COOKIES.get("name")
        password = request.POST.get("p1")
        password1 = request.POST.get("p2")
        conn = pymysql.connect(host="127.0.0.1", port=3306,
                               user="root", password="root",
                               db="bookstore", charset="utf8")

        if password != password1:
            return HttpResponse("两次密码输入不一致")
        else:
            cursor = conn.cursor()
            cursor.execute("update bookstore.user set user_password = '%s' where user_name = '%s'"%(password,user_name))
            conn.commit()
            cursor.close()
            conn.close()
            return render(request,'person.html')
@zhuang
def find_user(request):
    """"查找用户"""
    if request.method =="GET":
        return render(request,'find_user.html')
    else:
        user_name = request.POST.get("p1")
        conn = pymysql.connect(host="127.0.0.1", port=3306,
                               user="root", password="root",
                               db="bookstore", charset="utf8")
        cursor = conn.cursor()
        cursor.execute("select * from user where user_name='%s'" % user_name)
        shop = cursor.fetchall()
        conn.commit()
        cursor.close()
        conn.close()
        if shop is not None:
            shop = shop[0]
        return render(request,"find_result.html",context={'a':shop})
@zhuang
def del_user(request):
    """"删除用户"""
    if request.method == "GET":
        return render(request,'del_user.html')
    else:
        user_name = request.POST.get("p1")
        conn = pymysql.connect(host="127.0.0.1", port=3306,
                               user="root", password="root",
                               db="bookstore", charset="utf8")
        cursor = conn.cursor()
        cursor.execute("delete from bookstore.user where user_name='%s'"%user_name)
        conn.commit()
        cursor.close()
        conn.close()
        return render(request,'superadmin.html')
@zhuang
def change_user(request):
    """"更改用户信息"""
    if request.method =="GET":
        return render(request,"change_user.html")
    else:
        user_name = request.POST.get("p4")
        password = request.POST.get("p1")
        password1 = request.POST.get("p2")
        power = request.POST.get("p3")


        conn = pymysql.connect(host="127.0.0.1", port=3306,
                               user="root", password="root",
                               db="bookstore", charset="utf8")
        if password != password1:
            return HttpResponse("两次密码输入不一致")
        else:
            cursor = conn.cursor()
            cursor.execute("update bookstore.user set user_password = '%s',user_power = '%s' where user_name = '%s'"%(password,power, user_name))
            user = cursor.fetchall()
            print(user)
            conn.commit()
            cursor.close()
            conn.close()
            return render(request,'superadmin.html')
@zhuang
def add_user(request):
    """"增加用户信息"""
    if request.method =="GET":
        return render(request,'add_user.html')
    else:
        user_name = request.POST.get("p1")
        user_password = request.POST.get("p2")
        user_power = request.POST.get('p3')
        conn = pymysql.connect(host="127.0.0.1", port=3306,
                               user="root", password="root",
                               db="bookstore", charset="utf8")
        cursor = conn.cursor()
        cursor.execute("insert into user (user_name,user_password,user_power)values('%s','%s','%s')"%(user_name,user_password,user_power))
        conn.commit()
        cursor.close()
        conn.close()
        return render(request,'superadmin.html')
@zhuang
def find_result(request):
    """"查询结果"""
    if request.method =="GET":
        return  render(request,"find_result.html")
@zhuang
def del_shoppingcar(request):
    """"删除购物车"""
    del_goods_id = request.POST.get('p7')
    conn = pymysql.connect(host="127.0.0.1", port=3306,
                           user="root", password="root",
                           db="bookstore", charset="utf8")
    cursor = conn.cursor()
    cursor.execute("delete from bookstore.shoppingcar where goods_id = '%s'" % del_goods_id)
    conn.commit()
    cursor.close()
    conn.close()

    return redirect('shoppingcar')
@zhuang
def add_shoppingcar(request):
    """"增加购物车"""
    if request.method =="GET":
        return render(request,'shoppingcar.html')
    else:
        user_name = request.COOKIES.get("name")
        goods_id = request.POST.get("p3")
        goods_type = request.POST.get('p2')
        buy_number = request.POST.get('p1')
        if int(buy_number)<=0:
            return HttpResponse("真就您不买或者想送我东西呗")
        else:
            conn = pymysql.connect(host="127.0.0.1", port=3306,
                                   user="root", password="root",
                                   db="bookstore", charset="utf8")
            cursor = conn.cursor()
            cursor.execute("select user_id from user where user_name='%s'"%user_name)
            user_id = cursor.fetchall()

            conn.commit()
            cursor.close()

            cursor =conn.cursor()
            cursor.execute("insert into shoppingcar(user_id,goods_id,goods_type,buy_number)values('%s','%s','%s','%s')"%(user_id[0][0],goods_id,goods_type,buy_number))
            conn.commit()
            cursor.close()
            conn.close()
            return redirect('shoppingcar')
@zhuang
def read(request):
    """"浏览记录"""


    b= request.COOKIES.get("name")
    key = 'history_%s' % b
    # 取出用户最近浏览的5个商品的id
    history_li = r.lrange(key, 0, 4)

    books_li = []
    print(history_li)
    for i in history_li:
        conn = pymysql.connect(host="127.0.0.1", port=3306,
                               user="root", password="root",
                               db="bookstore", charset="utf8")
        cursor = conn.cursor()
        cursor.execute("select goods_img,goods_name,goods_price,goods_id from goods where goods_id='%s'" % i)
        shop = cursor.fetchall()
        books_li.append(shop[0])
        print(books_li)
    return render(request,"read.html",context={'a':books_li})
@zhuang
def checkout(request):
    """"下单"""
    user_name = request.COOKIES.get("name")
    conn = pymysql.connect(host="127.0.0.1", port=3306,
                           user="root", password="root",
                           db="bookstore", charset="utf8")
    cursor = conn.cursor()
    cursor.execute("select user_id from user where user_name='%s'" % user_name)
    user_id = cursor.fetchall()
    conn.commit()
    cursor.close()
    li = []
    cursor = conn.cursor()
    cursor.execute("select goods_id,buy_number,shopped_time from shopped where user_id ='%s'" % user_id[0][0])
    goods_id1 = cursor.fetchall()
    for i in goods_id1:
        cursor = conn.cursor()
        cursor.execute("select goods_img,goods_name,goods_price,goods_id from goods where goods_id = '%s'" % i[0])
        goods_mess = cursor.fetchall()
        goods_mess = i + goods_mess[0]
        li.append(goods_mess)
    conn.commit()
    cursor.close()
    return render(request,"checkout.html",context={'a':li})
@zhuang
def add_goods(request):
    """"商品上架"""
    if request.method == "GET":
        return render(request,'add_goods.html')
    else:
        goods_name = request.POST.get('p1')
        goods_price =request.POST.get('p2')
        goods_img = request.POST.get('p3')
        goods_info =request.POST.get('p4')
        conn = pymysql.connect(host="127.0.0.1", port=3306,
                               user="root", password="root",
                               db="bookstore", charset="utf8")
        cursor = conn.cursor()
        cursor.execute("insert into goods(goods_name,goods_price,goods_img,goods_info)values ('%s','%s','%s','%s')"%(goods_name,goods_price,goods_img,goods_info))
        conn.commit()
        cursor.close()
        conn.close()
        return render(request,'person.html')
@zhuang
def del_goods(request):
    """"商品下架"""
    if request.method=="GET":
        return render(request,'del_goods.html')
    else:
        goods_id = request.POST.get("p1")
        conn = pymysql.connect(host="127.0.0.1", port=3306,
                               user="root", password="root",
                               db="bookstore", charset="utf8")
        cursor = conn.cursor()
        cursor.execute("delete from bookstore.goods where goods_id = '%s'"%goods_id)
        conn.commit()
        cursor.close()
        conn.close()

        return render(request,"person.html")

def goods_paihang(request):

    conn = pymysql.connect(host="127.0.0.1", port=3306,
                           user="root", password="root",
                           db="bookstore", charset="utf8")

    cursor = conn.cursor()
    cursor.execute("select goods_sales,goods_id from goods")
    goods_sales = cursor.fetchall()

    li = []
    for i in goods_sales:
        li.append(i[0])

    li.sort(reverse=True)
    print(li, "ssssssssssssssssssssssssssssssssssssss")

    li123 = []
    for i in li:
        cursor = conn.cursor()
        cursor.execute("select goods_name,goods_price,goods_sales,goods_img,goods_size,goods_id from goods where goods_sales = '%s'" % (i))
        shop_main = cursor.fetchall()
        li123.append(shop_main[0])
    conn.commit()
    cursor.close()

    conn.close()


    return render(request,'goods_paihang.html',context={'b':li123})


@zhuang
def room(request):
    user_name = request.COOKIES.get('name')
    chat_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    return render(request, 'room.html', {'user_name': user_name, 'chat_time': chat_time})
