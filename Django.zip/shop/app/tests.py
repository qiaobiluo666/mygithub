
li = [2,3,5,9,8]
li.sort()
print(li[0:3])